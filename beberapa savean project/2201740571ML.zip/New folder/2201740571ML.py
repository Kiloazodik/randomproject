#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd 
import seaborn as sbn
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from scipy.stats import norm


# In[2]:


#input data/locate date

df = pd.read_csv('datasetMidExamCOMP6577.csv')
ft = ['X1','X2','X3','X4','X5','X6','X7','X8','X9','X10',
      'X11','X12','X13','X14','X15','X16','X17','X18','X19','X20']

y = df['Y']
X = df[ft]


# # Nomor 1

# In[3]:


df.describe()


# In[4]:


# target desc
df.Y.describe()


# In[5]:


# histogram
sbn.set(rc={'figure.figsize':(13,10)})
X.hist()


plt.show()


# In[6]:


# compare with normal distribution
sbn.set(rc={'figure.figsize':(13,7)})
sbn.distplot(df['Y'], fit=norm)

plt.legend(['Normalisasi'])
plt.ylabel('X axis(Frequency)')
plt.xlabel('Y axis(Data Y)')


plt.show()


# # No.2 algoritma learning apa yang cocok untuk memprediksi Y berdasarkan    fitur-fitur yang diberikan pada data tersebut

# In[7]:


model = LinearRegression()


#The modeling speed is fast, does not require very complicated calculations, and runs fast when the amount of data is large.
#The understanding and interpretation of each variable can be given according to the coefficient


# # No.3 Memilih fitur-fitur tersebut sebagai predictor dari Y! 

# In[8]:


df = pd.read_csv('datasetMidExamCOMP6577.csv')

y = df['Y']
X = df.drop('Y', axis=1)

# train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model.fit(X_train, y_train)


# ## Mencari data ft yang paling cocok dengan Y

# In[9]:


# coefficient
model.fit(X_train, y_train)
coef = {'Coefficient': model.coef_}
model_coef = pd.DataFrame(coef, X.columns)
model_coef


# ## Mengambil data yang relevan(data lebih dari 0(Minimal 1))

# In[10]:


# Data training dan data set yang sudah di split

ft = ['X1','X4','X6','X8','X10','X11','X13','X14','X15','X18']
y = df['Y']
X = df[ft]


# In[11]:


# Histogram setelah menggunakan data-data yang relevan

sbn.set(rc={'figure.figsize':(13,10)})
X.hist()


plt.show()


# In[12]:


# ini train splitnya
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# In[13]:


#evaluation dari learning model

def eval(y_pred, y_true=y_test):
    mae = mean_absolute_error(y_true, y_pred)
    mse = mean_squared_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    
    return mae, mse, r2


# # No.4 Melakukan training untuk mendapatkan prediction dengan x_train dan y_train

# In[14]:


# training model dengan feature yang baru

model.fit(X_train[ft], y_train)
y_pred = model.predict(X_test)
    
mae, mse, r2 = eval(y_pred)


# In[15]:


# prediction

pred = {
    'Actual': y_test,
    'Prediction': y_pred,
    'Error': y_test-y_pred
}
df_pred = pd.DataFrame(pred)
df_pred


# # No.5 MAE MSE dan R2

# In[16]:


# model evaluation

print('Mean Absolute Error: {}\n'.format(mae))
print('Mean Squared Error : {}\n'.format(mse))
print('R2 Score           : {}\n'.format(r2))


# ## 6A. Melakukan training dengan fitur yang coefficientnya paling besar(X8: 97,4)

# In[17]:


df = pd.read_csv('datasetMidExamCOMP6577.csv')
ft = ['X8']
y = df['Y']
X = df[ft]

# ini train splitnya
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# In[18]:


# training model lagi dengan feature yang paling bermanfaat(coefficientnya besar)

model.fit(X_train[ft], y_train)
y_pred = model.predict(X_test)
    
mae, mse, r2 = eval(y_pred)


# In[19]:


# prediction

pred = {'Actual': y_test,
        'Prediction': y_pred,
       'Error': y_test-y_pred}
df_pred = pd.DataFrame(pred)
df_pred


# In[20]:


# model evaluation

print('Mean Absolute Error: {}\n'.format(mae))
print('Mean Squared Error : {}\n'.format(mse))
print('R2 Score           : {}\n'.format(r2))


# ## 6B. Melakukan training dengan semua fitur(X1-X20)

# In[21]:


df = pd.read_csv('datasetMidExamCOMP6577.csv')

y = df['Y']
X = df.drop('Y', axis=1)

#ini train splitnya
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# In[22]:


# training model

model.fit(X_train, y_train)
y_pred = model.predict(X_test)
    
mae, mse, r2 = eval(y_pred)


# In[23]:


# prediction

pred = {
    'Actual': y_test,
    'Linear': y_pred,
    'Error': y_test-y_pred
}
df_pred = pd.DataFrame(pred)
df_pred


# In[24]:


# model evaluation

print('Mean Absolute Error: {}\n'.format(mae))
print('Mean Squared Error : {}\n'.format(mse))
print('R2 Score           : {}\n'.format(r2))


# # Source Method template:
#     https://towardsdatascience.com/a-beginners-guide-to-linear-regression-in-python-with-scikit-learn-83a8f7ae2b4f
# # Additional Seaborn template
#     https://stackoverflow.com/questions/55128462/how-to-normalize-seaborn-distplot
#     https://seaborn.pydata.org/
# # Linear regression explained
#     https://easyai.tech/en/ai-definition/linear-regression/
